# Elevate_lab_Task-1
This is my Day 1 Task in Machine Learning  as a Intern in Elevate Labs for a month during May 26th - June 26th

